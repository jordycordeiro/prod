
'use client'
import Topbar from '@/components/Topbar'
import Sidebar from '@/components/Sidebar'
import Canvas from '@/components/Canvas'
import ExameFisico from '@/components/ExameFisico'
import Observacoes from '@/components/Observacoes'
import Medicacoes from '@/components/Medicacoes'
import { useProdocStore } from '@/components/useProdocStore'
import { useEffect } from 'react'
import { applyPreset } from '@/components/theme/presets'

export default function ProdocPage(){
  const { state } = useProdocStore()
  useEffect(()=>{ try{ applyPreset(state.appearance as any) }catch{} }, [state.appearance])
  function renderMain(){
    if (state.activeKey === 'exame-fisico') return <ExameFisico />
    if (state.activeKey === 'observacoes-gerais') return <Observacoes />
    if (state.activeKey === 'med-unidade') return <Medicacoes />
    return <Canvas />
  }
  return (
    <div>
      <Topbar />
      <main className="container grid md:grid-cols-[280px_1fr] gap-4 px-4 py-4">
        <Sidebar />
        {renderMain()}
      </main>
    </div>
  )
}
