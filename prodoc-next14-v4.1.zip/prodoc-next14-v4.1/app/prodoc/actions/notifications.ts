'use server'

import { createClient } from '@/lib/supabase/server'

export async function publishTemplate(templateId: string, version: number) {
  const supabase = createClient()
  const { data, error } = await supabase.rpc('admin_publish_template', { template_id: templateId, version })
  if (error) throw error
  return data
}

export async function applyTemplate(broadcastId: string) {
  const supabase = createClient()
  const { data, error } = await supabase.rpc('apply_template_for_user', { bcast_id: broadcastId })
  if (error) throw error
  return data
}

export async function getInbox() {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('user_inbox')
    .select('id,broadcast_id,seen_at,created_at, broadcasts(title,version)')
    .order('created_at', { ascending: false })
  if (error) throw error
  return data
}
