// app/(app)/inbox/actions.ts  (substitua apenas applyInboxItem)
'use server'
import { revalidatePath } from 'next/cache'
import { createClient } from '@/lib/supabase/server'

export async function applyInboxItem(
  id: string,
  submenuId: string,
  mode: 'append'|'replace'|'merge' = 'append'
) {
  const supabase = createClient()
  const { data: { user }, error: authErr } = await supabase.auth.getUser()
  if (authErr || !user) return { ok:false, error:'unauthenticated' }
  if (!id) return { ok:false, error:'id ausente' }
  if (!submenuId) return { ok:false, error:'submenuId ausente' }

  // 1) inbox do usuário
  const { data: ib, error: ibErr } = await supabase
    .from('user_inbox')
    .select('id, payload, status, broadcast_id')
    .eq('id', id).eq('user_id', user.id).single()
  if (ibErr || !ib) return { ok:false, error: ibErr?.message ?? 'inbox não encontrado' }

  const payload: any = ib.payload || {}
  const adminId: string | undefined = payload?.admin_prescription_id
  const version: number | undefined = payload?.version

  type CardLite = { title: string; content_md: string; sort?: number }
  let cards: CardLite[] = []

  if (Array.isArray(payload?.cards)) {
    cards = payload.cards.map((c: any, i: number) => ({
      title: (c?.title ?? `Card ${i+1}`) as string,
      content_md: (c?.content_md ?? c?.body ?? '') as string,
      sort: c?.sort ?? i+1,
    }))
  } else if (payload?.title || payload?.content_md || payload?.body) {
    cards = [{ title: payload.title ?? 'Atualização', content_md: payload.content_md ?? payload.body ?? '', sort: 1 }]
  }
  if (!cards.length) return { ok:false, error:'payload vazio' }

  // 2) REPLACE => limpa user_prescriptions do submenu
  if (mode === 'replace') {
    const { error: delErr } = await supabase
      .from('user_prescriptions')
      .delete()
      .match({ user_id: user.id, submenu_id: submenuId })
    if (delErr) return { ok:false, error:'Erro ao limpar (replace): ' + delErr.message }
  }

  // helpers
  const normKey = (s: string) => (s||'').trim().toLocaleLowerCase()

  if (mode === 'merge') {
    // 3A) merge por based_on_id (se payload tem admin_prescription_id)
    if (adminId) {
      const { data: ov } = await supabase
        .from('user_prescriptions')
        .select('id')
        .match({ user_id: user.id, based_on_id: adminId })
        .maybeSingle()

      if (ov?.id) {
        const c = cards[0] // delta pontual
        const { error: updErr } = await supabase
          .from('user_prescriptions')
          .update({ title: c.title, content_md: c.content_md, updated_at: new Date().toISOString() })
          .eq('id', ov.id)
        if (updErr) return { ok:false, error:'Erro ao atualizar (merge by admin): ' + updErr.message }
      } else {
        // primeira customização desse admin_card → inserir já “vinculado”
        const rows = cards.map((c, i) => ({
          user_id: user.id,
          submenu_id: submenuId,
          title: c.title,
          content_md: c.content_md,
          is_custom: true,
          based_on_id: adminId,
          based_on_version: version ?? null,
        }))
        const { error: insErr } = await supabase.from('user_prescriptions').insert(rows)
        if (insErr) return { ok:false, error:'Erro ao inserir (merge first custom): ' + insErr.message }
      }
    } else {
      // 3B) merge por título
      const { data: existing, error: exErr } = await supabase
        .from('user_prescriptions')
        .select('id, title')
        .match({ user_id: user.id, submenu_id: submenuId })
      if (exErr) return { ok:false, error:'Erro ao buscar destino (merge): ' + exErr.message }

      const map = new Map<string,string>()
      ;(existing || []).forEach(r => map.set(normKey(r.title), r.id))

      const toUpd:any[] = [], toIns:any[] = []
      cards.forEach((c,i) => {
        const id = map.get(normKey(c.title))
        if (id) toUpd.push({ id, title: c.title, content_md: c.content_md })
        else toIns.push({
          user_id: user.id, submenu_id: submenuId,
          title: c.title, content_md: c.content_md,
          is_custom: true
        })
      })

      if (toUpd.length) {
        const { error: updErr } = await supabase.from('user_prescriptions').upsert(toUpd, { onConflict: 'id' })
        if (updErr) return { ok:false, error:'Erro ao atualizar (merge): ' + updErr.message }
      }
      if (toIns.length) {
        const { error: insErr } = await supabase.from('user_prescriptions').insert(toIns)
        if (insErr) return { ok:false, error:'Erro ao inserir (merge): ' + insErr.message }
      }
    }
  } else {
    // 4) append (e replace + append)
    const rows = cards.map((c,i) => ({
      user_id: user.id,
      submenu_id: submenuId,
      title: c.title,
      content_md: c.content_md,
      is_custom: true,
      based_on_id: adminId ?? null,
      based_on_version: version ?? null,
    }))
    const { error: insErr } = await supabase.from('user_prescriptions').insert(rows)
    if (insErr) return { ok:false, error:'Erro ao inserir (append/replace): ' + insErr.message }
  }

  // 5) marca inbox como lido/aplicado
  const { error: seenErr } = await supabase
    .from('user_inbox')
    .update({ status: 'applied', applied_at: new Date().toISOString() })
    .eq('id', id).eq('user_id', user.id)
  if (seenErr) console.warn('applyInboxItem: status não atualizado:', seenErr.message)

  try { revalidatePath('/prodoc') } catch {}
  return { ok:true }
}
