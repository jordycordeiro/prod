'use server'

import { createClient } from '@/lib/supabase/server'

// Cria override na primeira edição de um card global
export async function ensureOverride(adminCardId: string) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { ok: false, error: 'unauthenticated' }

  const { data: admin } = await supabase
    .from('admin_prescriptions')
    .select('id, submenu_id, title, content_md, version')
    .eq('id', adminCardId)
    .single()

  if (!admin) return { ok: false, error: 'admin card not found' }

  const { data: exists } = await supabase
    .from('user_prescriptions')
    .select('id')
    .match({ user_id: user.id, based_on_id: admin.id })
    .maybeSingle()

  if (exists?.id) return { ok: true, user_card_id: exists.id }

  const { data, error } = await supabase
    .from('user_prescriptions')
    .insert({
      user_id: user.id,
      submenu_id: admin.submenu_id,
      title: admin.title,
      content_md: admin.content_md,
      is_custom: true,
      based_on_id: admin.id,
      based_on_version: admin.version,
    })
    .select('id')
    .single()

  if (error) return { ok: false, error: error.message }
  return { ok: true, user_card_id: data.id }
}
