'use server'

import { createClient } from '@/lib/supabase/server'

export type EffectiveCard = {
  admin_card_id: string
  user_card_id: string | null
  submenu_id: string
  title: string
  content_md: string
}

/**
 * Visão efetiva por submenu:
 * - lê TODOS os cards globais (admin_prescriptions)
 * - lê overrides do usuário (user_prescriptions)
 * - aplica override quando existir, senão usa o global
 */
export async function listEffectiveCards(submenuId: string): Promise<EffectiveCard[]> {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return []

  // 1) globais
  const { data: globals, error: gErr } = await supabase
    .from('admin_prescriptions')
    .select('id, submenu_id, title, content_md')
    .eq('submenu_id', submenuId)
    .order('updated_at', { ascending: true })
  if (gErr || !globals) return []

  // 2) overrides do usuário
  const { data: overs } = await supabase
    .from('user_prescriptions')
    .select('id, based_on_id, submenu_id, title, content_md')
    .eq('submenu_id', submenuId)
    .eq('user_id', user.id)

  const byBase = new Map<string, { id: string, title: string, content_md: string }>()
  for (const o of (overs ?? [])) {
    if (o.based_on_id) byBase.set(o.based_on_id, { id: o.id, title: o.title, content_md: o.content_md })
  }

  return globals.map(g => {
    const ov = byBase.get(g.id)
    return {
      admin_card_id: g.id,
      user_card_id: ov?.id ?? null,
      submenu_id: g.submenu_id,
      title: ov?.title ?? g.title,
      content_md: ov?.content_md ?? g.content_md,
    }
  })
}

/** Busca o primeiro submenu “válido” (pela sidebar padrão) */
export async function getFirstSubmenuId(): Promise<string | null> {
  const supabase = createClient()
  const { data } = await supabase
    .from('submenus')
    .select('id')
    .order('sort', { ascending: true, nullsFirst: false })
    .order('created_at', { ascending: true })
    .limit(1)
    .maybeSingle()
  return data?.id ?? null
}
