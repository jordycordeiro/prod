'use server'

import { createClient } from '@/lib/supabase/server'
import { revalidatePath } from 'next/cache'

const slugify = (s: string) =>
  s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
   .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '')

export async function createMenuWithDefaultSubmenu(title: string) {
  const supabase = createClient()
  const t = (title ?? '').trim()
  if (!t) throw new Error('Título é obrigatório.')

  const now = new Date().toISOString()
  const { data: { user } } = await supabase.auth.getUser()

  const base = slugify(t)
  const key = `${base}-${Math.random().toString(36).slice(2, 6)}`

  // 1️⃣ Cria o MENU PAI
  const { data: menu, error: menuErr } = await supabase
    .from('menus')
    .insert({
      id: crypto.randomUUID(),
      title: t,
      label: t,
      key,
      slug: key,
      sort: 1000,
      created_at: now,
    })
    .select('id, title, key')
    .single()
  if (menuErr) throw menuErr

  // 2️⃣ Garante coluna is_fixed em submenus (idempotente)
  await supabase.rpc('exec_sql', {
    sql: `alter table public.submenus add column if not exists is_fixed boolean default false;`
  }).catch(() => {})

  // 3️⃣ Cria SUBMENU padrão "Geral" (fixo)
  const { data: sub, error: subErr } = await supabase
    .from('submenus')
    .insert({
      id: crypto.randomUUID(),
      menu_id: menu.id,
      menu_key: menu.key,
      title: 'Geral',
      sort: 10,
      sort_order: 10,
      is_global: true,
      is_fixed: true, // 🔒 não pode ser apagado isoladamente
      created_at: now,
      created_by: user?.id ?? null,
      updated_at: now,
    })
    .select('id, title, menu_id')
    .single()
  if (subErr) throw subErr

  // 4️⃣ Garante visibilidade para o criador
  if (user?.id) {
    await supabase.from('user_menus').insert({
      user_id: user.id,
      menu_id: menu.id,
      submenu_id: sub.id,
      is_visible: true,
      sort_order: 10,
      created_at: now,
      updated_at: now,
    }).catch(() => {})
  }

  try {
    revalidatePath('/admin/studio')
    revalidatePath('/prodoc')
  } catch {}

  return { menu, submenu: sub }
}
