'use server'

import { createClient } from '@/lib/supabase/server'

export async function ignoreInbox(id: string) {
  const supabase = createClient()

  // precisa ter usuário logado
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) {
    return { ok: false, error: 'unauthenticated' }
  }

  // marca como lido somente a linha do próprio usuário (RLS protege)
  const { error } = await supabase
    .from('user_inbox')
    .update({ seen_at: new Date().toISOString() })
    .eq('id', id)
    .eq('user_id', user.id)

  if (error) return { ok: false, error: error.message }
  return { ok: true }
}
