// app/(prodoc)/actions/notifications.ts
'use server'

import { createClient } from '@/lib/supabase/server'

export async function getInbox(onlyUnread: boolean = true) {
  const supabase = createClient()
  let query = supabase
    .from('user_inbox')
    .select(`
      id, broadcast_id, template_id, version, seen_at, created_at, applied_version,
      muted_until_version,
      templates:template_id ( title )
    `)
    .order('created_at', { ascending: false })

  if (onlyUnread) {
    // não lidas E não mutadas
    query = query
      .is('seen_at', null)
      .or('muted_until_version.is.null,version.gt.muted_until_version')
  }

  const { data, error } = await query
  if (error) throw error
  return data
}