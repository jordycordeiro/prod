import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET() {
  const supabase = createClient()
  const { data: { user }, error: authErr } = await supabase.auth.getUser()
  if (authErr || !user) return NextResponse.json({ count: 0 }, { status: 200 })

  const { count, error } = await supabase
    .from('user_inbox')
    .select('id', { count: 'exact', head: true })
    .eq('user_id', user.id)
    .eq('status', 'unread')

  if (error) return NextResponse.json({ count: 0 }, { status: 200 })
  return NextResponse.json({ count: count ?? 0 }, { status: 200 })
}
