import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function POST(req: Request) {
  const supabase = createClient()
  const { data: { user }, error: authErr } = await supabase.auth.getUser()
  if (authErr || !user) return NextResponse.json({ ok: false, error: 'unauthenticated' }, { status: 401 })

  const { ids } = await req.json().catch(() => ({ ids: [] as string[] }))
  if (!Array.isArray(ids) || ids.length === 0) {
    return NextResponse.json({ ok: true, updated: 0 }, { status: 200 })
  }

  const { error } = await supabase
    .from('user_inbox')
    .update({ status: 'read' })
    .in('id', ids)
    .eq('user_id', user.id)

  if (error) return NextResponse.json({ ok: false, error: error.message }, { status: 500 })
  return NextResponse.json({ ok: true, updated: ids.length }, { status: 200 })
}
