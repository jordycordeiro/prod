// app/api/inbox/apply/[id]/route.ts
import { NextResponse } from 'next/server';
import { applyInboxItem } from '@/app/(app)/inbox/actions';


export async function PATCH(req: Request, { params }: { params: { id: string } }) {
const id = params.id;
const body = await req.json().catch(() => ({}));
const result = await applyInboxItem(id, body);
return NextResponse.json(result, { status: result.ok ? 200 : 400 });
}