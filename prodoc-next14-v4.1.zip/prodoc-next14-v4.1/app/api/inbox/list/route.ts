import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(req: Request) {
  const supabase = createClient()
  const { data: { user }, error: authErr } = await supabase.auth.getUser()
  if (authErr || !user) return NextResponse.json([], { status: 200 })

  const { searchParams } = new URL(req.url)
  const onlyUnread = searchParams.get('onlyUnread') === '1'

  let q = supabase
    .from('user_inbox')
    .select('id, status, payload, created_at')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })

  if (onlyUnread) q = q.eq('status', 'unread')

  const { data, error } = await q
  if (error) return NextResponse.json({ ok: false, error: error.message }, { status: 500 })
  return NextResponse.json(data ?? [], { status: 200 })
}
