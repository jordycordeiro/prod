import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function POST() {
  const supabase = createClient()
  const { data: bc } = await supabase
    .from('broadcasts')
    .select('id, admin_prescription_id, version')
    .order('created_at', { ascending: false })
    .limit(1)
    .maybeSingle()

  if (!bc) return NextResponse.json({ ok:false, error:'sem broadcast' }, { status: 404 })

  const { error } = await supabase.rpc('fanout_inbox_for_overrides', {
    p_admin_card_id: bc.admin_prescription_id,
    p_broadcast_id: bc.id,
    p_version: bc.version,
  })
  if (error) return NextResponse.json({ ok:false, error: error.message }, { status: 500 })
  return NextResponse.json({ ok:true, fanout:true, bc }, { status: 200 })
}
