// app/api/admin/publish/route.ts
import { NextResponse } from 'next/server'
import { publishAdminCard } from '@/app/(app)/admin/actions'

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const { id, submenu_id, title, content_md } = body || {}
    if (!submenu_id || !title) {
      return NextResponse.json({ ok: false, error: 'submenu_id e title são obrigatórios' }, { status: 400 })
    }
    const res = await publishAdminCard({ id, submenu_id, title, content_md: content_md ?? '' })
    return NextResponse.json(res, { status: 200 })
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message || 'erro inesperado' }, { status: 500 })
  }
}
