import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const out: any = { user }

  // profile/admin?
  const { data: profile } = await supabase
    .from('profiles')
    .select('id,email,role')
    .eq('id', user?.id ?? '')
    .maybeSingle()
  out.profile = profile

  // últimas publicações
  const { data: lastAdmin } = await supabase
    .from('admin_prescriptions')
    .select('id, submenu_id, title, version, updated_at')
    .order('updated_at', { ascending: false })
    .limit(3)
  out.lastAdmin = lastAdmin ?? []

  const { data: lastBroadcasts } = await supabase
    .from('broadcasts')
    .select('id, admin_prescription_id, version, created_at')
    .order('created_at', { ascending: false })
    .limit(5)
  out.lastBroadcasts = lastBroadcasts ?? []

  // sino do usuário atual
  const { data: inbox } = await supabase
    .from('user_inbox')
    .select('id, status, created_at')
    .eq('user_id', user?.id ?? '')
    .order('created_at', { ascending: false })
    .limit(10)
  out.inbox = inbox ?? []

  // visão efetiva (se você passar ?submenu=<uuid>)
  // Ex.: /api/admin/diagnostics?submenu=...
  try {
    const url = new URL( (globalThis as any).location ? location.href : 'http://local.test' )
  } catch {}
  return NextResponse.json(out, { status: 200 })
}
