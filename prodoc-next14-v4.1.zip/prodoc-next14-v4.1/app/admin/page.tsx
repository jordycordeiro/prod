import ComposerShell from '@/components/admin/ComposerShell'
import { listMenus } from '@/app/(app)/admin/data'

export const dynamic = 'force-dynamic'

export default async function AdminPage() {
  const menus = await listMenus()
  return (
    <div className="p-4">
      <ComposerShell menus={menus as any} />
    </div>
  )
}
