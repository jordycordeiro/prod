"use client";

import { useEffect, useState } from "react";
import { AdminBlockList } from "@/components/admin/BlockList";       // passo 2
import { AdminTextEditor } from "@/components/admin/TemplateEditor"; // passo 3

type Scope = "exame_fisico" | "observacoes" | "medicacoes";

export default function StudioClient({ initialScope }: { initialScope: Scope }) {
  const [scope, setScope] = useState<Scope>(initialScope);
  const [pickedId, setPickedId] = useState<string | null>(null);

  // Se o usuário clicar nos menus do seu Sidebar (que trocam ?scope=...)
  useEffect(() => {
    const onPop = () => {
      const usp = new URLSearchParams(window.location.search);
      const s = usp.get("scope") as Scope | null;
      const allowed: Scope[] = ["exame_fisico", "observacoes", "medicacoes"];
      if (s && allowed.includes(s) && s !== scope) {
        setScope(s);
        setPickedId(null); // reseta o editor ao trocar de menu-pai
      }
    };
    window.addEventListener("popstate", onPop);
    // executa uma vez ao montar (caso tenha navegado via pushState fora)
    onPop();
    return () => window.removeEventListener("popstate", onPop);
  }, [scope]);

  return (
    // mantenha o seu casulo externo; aqui só organizamos as duas colunas
    <div className="grid gap-6 lg:grid-cols-[280px_minmax(0,1fr)]">
      {/* Coluna esquerda: lista de blocos do admin para o escopo atual */}
      <div>
        <AdminBlockList scope={scope} onPick={(id) => setPickedId(id)} />
      </div>

      {/* Canvas central: editor de texto do bloco selecionado */}
      <div>
        {pickedId ? (
          <AdminTextEditor templateId={pickedId} />
        ) : (
          <div className="text-sm text-slate-500">
            Selecione um item na barra lateral para começar.
          </div>
        )}
      </div>
    </div>
  );
}
