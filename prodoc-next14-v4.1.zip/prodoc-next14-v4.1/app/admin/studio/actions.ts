"use server";

/**
 * Admin Studio – Server Actions
 * ----------------------------------------------------------
 * Este módulo dá suporte ao modo Admin dentro do Canvas:
 *  - listAdminBlocks(scope)         → lista os blocos do menu-pai (Exame/Queixas/Medicações)
 *  - ensureAdminTemplatesFromMyUser → faz o seed a partir das prescrições do próprio admin
 *  - loadOrCreateTemplate(parent, submenu)
 *  - getTemplate(id)
 *  - saveDraftTemplate(id, text, note?)
 *  - publishTemplate(id, nextVersion, message?)
 *
 * Requisitos de tabelas (ajuste os nomes se preciso):
 *  - prescriptions: { user_id, scope, submenu, content(jsonb), updated_at }
 *  - templates:     { id, slug, title, kind, default_parent, default_submenu, status, version, content(jsonb) }
 *  - (opcional) um RPC/ tabela p/ notificação no sino — veja a função notifyEveryone()
 */

import { createClient } from "@supabase/supabase-js";

// --------------------------------------------
// Tipos compartilhados com o Admin Canvas
// --------------------------------------------
export type Scope = "exame_fisico" | "observacoes" | "medicacoes";

// --------------------------------------------
// Supabase — client de uso exclusivo no servidor
// (prefira SERVICE_ROLE para publicação/seed)
// --------------------------------------------
function supa() {
  const url  = process.env.NEXT_PUBLIC_SUPABASE_URL!;
  const key  = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;
  return createClient(url, key, { auth: { persistSession: false } });
}

// --------------------------------------------
// Notificação (sino) — deixe “best-effort”
// Troque pelo seu RPC/tabela real de notificação.
// --------------------------------------------
async function notifyEveryone(payload: { title: string; body?: string }) {
  const sb = supa();
  // 1) Exemplo chamando um RPC (se existir):
  try {
    const { error } = (await sb.rpc("notify_template_published", {
      title: payload.title,
      body: payload.body ?? null,
    })) as any;
    if (!error) return;
  } catch {}
  // 2) Fallback: gravar em uma tabela "inbox" (se existir no seu projeto)
  try {
    await sb.from("inbox").insert({
      kind: "template_published",
      title: payload.title,
      body: payload.body ?? null,
    });
  } catch {
    // tudo bem se não houver: notificação é "best-effort"
  }
}

// --------------------------------------------
// Seed: clona os blocos do próprio usuário
// para templates do Admin (rascunho, versão 1).
// --------------------------------------------
export async function ensureAdminTemplatesFromMyUser(scope: Scope) {
  const sb = supa();

  // já existe algo publicado ou rascunho para esse scope?
  const { data: exists, error: e0 } = await sb
    .from("templates")
    .select("id")
    .eq("default_parent", scope)
    .limit(1);
  if (e0) throw new Error(e0.message);
  if (exists?.length) return { created: 0 };

  // tenta inferir um "admin atual" pelo último que publicou algo (fallback)
  let me: string | null = null;
  try {
    const { data } = await sb
      .from("prescriptions")
      .select("user_id")
      .eq("scope", scope)
      .order("updated_at", { ascending: false })
      .limit(1);
    me = (data && data[0]?.user_id) || null;
  } catch {}

  // busca as prescrições do usuário "me" para esse escopo
  const { data: rows, error: e1 } = await sb
    .from("prescriptions")
    .select("submenu, content, updated_at")
    .eq("scope", scope)
    .order("updated_at", { ascending: false });

  if (e1) throw new Error(e1.message);

  const bySubmenu = new Map<string, any>();
  for (const r of rows ?? []) {
    const name = (r.submenu || "").toString().trim();
    if (!name) continue;
    if (!bySubmenu.has(name)) bySubmenu.set(name, r);
  }

  const toInsert: any[] = [];
  if (bySubmenu.size) {
    for (const [submenu, r] of bySubmenu) {
      const text = typeof r?.content?.text === "string" ? (r.content.text as string) : "";
      toInsert.push({
        slug: (scope + "-" + submenu).toLowerCase().replace(/\s+/g, "-"),
        title: submenu,
        kind: scope,
        default_parent: scope,
        default_submenu: submenu,
        status: "draft",
        version: 1,
        content: { text },
      });
    }
  } else {
    // nenhum dado de origem? cria placeholders úteis
    const placeholders =
      scope === "exame_fisico"
        ? ["GERAL", "AR", "ACV", "ABD", "MMII"]
        : scope === "observacoes"
        ? ["Síndrome Gripal", "Tosse Crônica", "Dor Torácica"]
        : ["Dipirona", "Ondansetrona", "Hidratação EV"];

    for (const name of placeholders) {
      toInsert.push({
        slug: (scope + "-" + name).toLowerCase().replace(/\s+/g, "-"),
        title: name,
        kind: scope,
        default_parent: scope,
        default_submenu: name,
        status: "draft",
        version: 1,
        content: { text: "" },
      });
    }
  }

  if (!toInsert.length) return { created: 0 };

  const { data: created, error: e2 } = await sb.from("templates").insert(toInsert).select("id");
  if (e2) throw new Error(e2.message);

  return { created: created?.length ?? 0 };
}

// --------------------------------------------
// Lista blocos do Admin p/ o escopo
// (se não houver, aciona o seed e tenta de novo)
// --------------------------------------------
export async function listAdminBlocks(scope: Scope) {
  const sb = supa();

  const { data, error } = await sb
    .from("templates")
    .select("id, default_submenu")
    .eq("default_parent", scope)
    .order("default_submenu", { ascending: true });

  if (error) throw new Error(error.message);

  if (!data?.length) {
    await ensureAdminTemplatesFromMyUser(scope);
    const { data: again } = await sb
      .from("templates")
      .select("id, default_submenu")
      .eq("default_parent", scope)
      .order("default_submenu", { ascending: true });

    return (again ?? []).map((r) => ({
      id: String(r.id),
      name: String(r.default_submenu),
    }));
  }

  return data.map((r) => ({
    id: String(r.id),
    name: String(r.default_submenu),
  }));
}

// --------------------------------------------
// Carrega um template por id
// --------------------------------------------
export async function getTemplate(templateId: string) {
  const sb = supa();
  const { data, error } = await sb.from("templates").select("*").eq("id", templateId).single();
  if (error) throw new Error(error.message);
  return data;
}

// --------------------------------------------
// Carrega (ou cria) um template para parent/submenu
// usado pelo editor de texto do Admin
// --------------------------------------------
export async function loadOrCreateTemplate(parent: Scope, submenu: string) {
  const sb = supa();
  const sub = (submenu || "").trim();

  // tenta achar
  const { data: found } = await sb
    .from("templates")
    .select("*")
    .eq("default_parent", parent)
    .eq("default_submenu", sub)
    .limit(1);

  if (found && found.length) return found[0];

  // cria rascunho vazio
  const payload = {
    slug: (parent + "-" + sub).toLowerCase().replace(/\s+/g, "-"),
    title: sub,
    kind: parent,
    default_parent: parent,
    default_submenu: sub,
    status: "draft",
    version: 1,
    content: { text: "" },
  };

  const { data: created, error } = await sb.from("templates").insert(payload).select("*").single();
  if (error) throw new Error(error.message);
  return created;
}

// --------------------------------------------
// Salva rascunho (texto simples) no template
// --------------------------------------------
export async function saveDraftTemplate(templateId: string, text: string, note?: string) {
  const sb = supa();
  const { error } = await sb.from("templates").update({ content: { text }, status: "draft" }).eq("id", templateId);
  if (error) throw new Error(error.message);
  return { ok: true };
}

// --------------------------------------------
// Publica template: define versão, status e
// dispara notificação no sino (best-effort)
// --------------------------------------------
export async function publishTemplate(templateId: string, nextVersion: number, message?: string) {
  const sb = supa();

  // 1) Atualiza status/versão do template
  const { error: e1 } = await sb
    .from("templates")
    .update({ status: "published", version: nextVersion })
    .eq("id", templateId);
  if (e1) throw new Error(e1.message);

  // 2) Dispara broadcast para TODOS os usuários (cria itens no user_inbox)
  const { error: e2 } = await sb.rpc("publish_template", {
    p_template_id: templateId,
    p_version: nextVersion,
    p_note: message ?? null,
  } as any);
  if (e2) throw new Error(e2.message);

  // 3) Notificação "best-effort" (sino)
  try {
    const { data: t } = await sb
      .from("templates")
      .select("default_parent, default_submenu")
      .eq("id", templateId)
      .single();
    if (t) {
      const title = `Novo padrão publicado: ${String(t.default_parent || "").toUpperCase()} • ${t.default_submenu}`;
      await notifyEveryone({ title, body: message ?? `Versão ${nextVersion} publicada.` });
    }
  } catch {}

  return { ok: true };
}
