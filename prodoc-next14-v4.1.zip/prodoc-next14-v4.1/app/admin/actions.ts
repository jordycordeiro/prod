// Ponteiro para compatibilidade com "@/app/admin/actions"
export * from '../(app)/admin/actions'

import {
  publishAdminCard,
  upsertTemplate,
  publishTemplate,
} from '../(app)/admin/actions'

// Default export (para .default?.publishTemplate)
const AdminActionsDefault = { publishAdminCard, upsertTemplate, publishTemplate }
export default AdminActionsDefault
