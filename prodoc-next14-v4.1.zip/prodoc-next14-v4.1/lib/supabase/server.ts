import 'server-only'
import { cookies, headers } from 'next/headers'
import { createServerClient as createSbServerClient } from '@supabase/ssr'

function requireEnv(name: string) {
  const val = process.env[name]
  if (!val) {
    // Mensagem clara em dev/build
    throw new Error(`[Supabase ENV] Missing ${name}. Defina no .env.local`)
  }
  return val
}

export function createClient() {
  const url = requireEnv('NEXT_PUBLIC_SUPABASE_URL')
  const anon = requireEnv('NEXT_PUBLIC_SUPABASE_ANON_KEY')

  // Se usar service role só no Admin Studio:
  const service = process.env.SUPABASE_SERVICE_ROLE_KEY || null

  const cookieStore = cookies()
  const h = headers()

  // SSR helper oficial do supabase para Next 13/14
  const client = createSbServerClient(url, service || anon, {
    cookies: {
      get(name) { return cookieStore.get(name)?.value },
      set(name, value, options) { cookieStore.set({ name, value, ...options }) },
      remove(name, options) { cookieStore.set({ name, value: '', ...options, maxAge: 0 }) },
    },
    headers: {
      // encaminhar cabeçalhos úteis (auth, x-forwarded-host etc.)
      'x-forwarded-host': h.get('x-forwarded-host') ?? '',
      'x-forwarded-proto': h.get('x-forwarded-proto') ?? '',
      'x-real-ip': h.get('x-real-ip') ?? '',
    },
  })

  return client
}
