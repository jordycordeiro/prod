// lib/supabaseService.ts — client EXCLUSIVO DO SERVIDOR usando Service Role
import { createClient } from '@supabase/supabase-js'

export function supabaseService() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY

  if (!url) throw new Error('NEXT_PUBLIC_SUPABASE_URL ausente')
  if (!key) throw new Error('SUPABASE_SERVICE_ROLE_KEY ausente no servidor')

  // IMPORTANTE: enviar Authorization: Bearer <SERVICE_ROLE_KEY>
  // para o PostgREST reconhecer o JWT como service_role
  return createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: {
      headers: {
        Authorization: `Bearer ${key}`,
      },
    },
  })
}

export default supabaseService
