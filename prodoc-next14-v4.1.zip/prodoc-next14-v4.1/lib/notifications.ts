// lib/notifications.ts
import { createClient } from '@supabase/supabase-js';

export async function getUnreadCount(supabase: ReturnType<typeof createClient>, userId: string) {
  const { data, error } = await supabase
    .from('notifications')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', userId)
    .is('read_at', null);

  if (error) throw error;
  return data?.length === 0 ? 0 : (data as any).length ?? (data as any).count ?? 0;
}
