// stores/useAdminComposer.ts
'use client'

import { useCallback, useRef } from 'react'
// Importa tudo para suportar default export ou named export
import * as AdminActions from '@/app/admin/actions'
import { useProdocStore } from '@/components/useProdocStore'

type Sex = 'A' | 'M' | 'F'
type Meta = { title: string; kind: string; sex?: Sex }

function getUpsert() {
  const fn: any = (AdminActions as any).upsertTemplate ?? (AdminActions as any).default?.upsertTemplate
  if (typeof fn !== 'function') {
    throw new Error('upsertTemplate não encontrado em "@/app/admin/actions". Exporte a função (named ou default).')
  }
  return fn as (payload: any) => Promise<any>
}
function getPublish() {
  const fn: any = (AdminActions as any).publishTemplate ?? (AdminActions as any).default?.publishTemplate
  if (typeof fn !== 'function') {
    throw new Error('publishTemplate não encontrado em "@/app/admin/actions". Exporte a função (named ou default).')
  }
  return fn as (id: string, note?: string) => Promise<any>
}

export function useAdminComposer() {
  const store = useProdocStore() as any
  const lastTemplateId = useRef<string | null>(null)

  const readState = () => {
    const s: any = (useProdocStore as any)?.getState?.() ?? store ?? {}
    return s
  }

  const takeFromCanvas = useCallback(async () => {
    const s = readState()
    const metaSrc: any =
      s?.composer?.meta ?? s?.meta ?? s?.activeMeta ?? s?.canvas?.meta ?? {}
    const bodySrc: any =
      s?.composer?.markdown ?? s?.markdown ?? s?.canvas?.markdown ?? s?.currentMarkdown ?? s?.content_md ?? ''
    const jsonSrc: any =
      s?.composer?.json ?? s?.canvas?.json ?? s?.content_json ?? s?.currentContent ?? null

    const meta: Meta = {
      title: metaSrc?.title ?? 'Sem título',
      kind: metaSrc?.kind ?? 'PADRAO',
      sex: (metaSrc?.sex as Sex) ?? 'A',
    }
    const body: string = typeof bodySrc === 'string' ? bodySrc : JSON.stringify(bodySrc ?? '', null, 2)
    const content_json: any = jsonSrc

    return { meta, body, content_json }
  }, [])

  const saveDraft = useCallback(async () => {
    const { meta, body, content_json } = await takeFromCanvas()
    const upsert = getUpsert()

    const payload: any = {
      id: lastTemplateId.current ?? undefined,
      title: meta?.title ?? 'Sem título',
      kind: meta?.kind ?? 'PADRAO',
      sex: (meta?.sex as Sex) ?? 'A',
      content_md: body ?? '',
      content_json: content_json ?? null,
    }

    const row = await upsert(payload)
    const id = (typeof row === 'string' ? row : row?.id) as string | undefined
    if (id) lastTemplateId.current = id
    return row
  }, [takeFromCanvas])

  const publish = useCallback(async (note?: string) => {
    if (!lastTemplateId.current) {
      const row = await saveDraft()
      const id = (typeof row === 'string' ? row : row?.id) as string | undefined
      if (!id) throw new Error('Falha ao salvar o rascunho antes de publicar.')
      lastTemplateId.current = id
    }
    const publishFn = getPublish()
    return await publishFn(lastTemplateId.current as string, note)
  }, [saveDraft])

  const resetCanvas = useCallback(() => {
    const s = readState()
    s?.reset?.(); s?.resetCanvas?.(); s?.clearSelection?.()
  }, [])

  return { takeFromCanvas, saveDraft, publish, resetCanvas, lastTemplateId }
}
