-- prod_baseline.sql
-- Clean, minimal baseline to manage templates and broadcasts via service-role RPCs
-- Safe to run multiple times (uses CREATE IF NOT EXISTS / CREATE OR REPLACE).

------------------------------------------------------------
-- 0) Extensions
------------------------------------------------------------
create extension if not exists "uuid-ossp";
create extension if not exists "pgcrypto";

------------------------------------------------------------
-- 1) Tables
------------------------------------------------------------

-- 1.1 templates
create table if not exists public.templates (
  id            uuid primary key default gen_random_uuid(),
  kind          text not null default 'generic',
  title         text not null,
  content_md    text,
  content_json  jsonb not null default '{}'::jsonb,
  sex           text not null default 'u',         -- u (unisex), m, f
  status        text not null default 'draft',     -- draft|published|archived
  version       integer not null default 1,
  set_id        uuid,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- updated_at trigger
create or replace function public.tg_touch_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end; $$;

drop trigger if exists trg_templates_touch on public.templates;
create trigger trg_templates_touch
before update on public.templates
for each row
execute function public.tg_touch_updated_at();

-- Helpful index
create index if not exists idx_templates_status on public.templates(status);
create index if not exists idx_templates_set on public.templates(set_id);

-- 1.2 template_broadcasts
create table if not exists public.template_broadcasts (
  id           uuid primary key default gen_random_uuid(),
  template_id  uuid not null references public.templates(id) on delete cascade,
  channel      text not null default 'internal',
  status       text not null default 'queued', -- queued|sent|failed
  payload      jsonb not null default '{}'::jsonb,
  sent_at      timestamptz,
  created_at   timestamptz not null default now()
);

create index if not exists idx_template_broadcasts_template on public.template_broadcasts(template_id);
create index if not exists idx_template_broadcasts_status on public.template_broadcasts(status);

------------------------------------------------------------
-- 2) RLS (keep it simple: anyone can read; writes via service-role)
------------------------------------------------------------
alter table public.templates enable row level security;
alter table public.template_broadcasts enable row level security;

-- Drop existing policies (idempotent)
do $$ begin
  if exists (select 1 from pg_policies where schemaname='public' and tablename='templates' and policyname='read_all_templates') then
    execute 'drop policy read_all_templates on public.templates';
  end if;
  if exists (select 1 from pg_policies where schemaname='public' and tablename='template_broadcasts' and policyname='read_all_broadcasts') then
    execute 'drop policy read_all_broadcasts on public.template_broadcasts';
  end if;
end $$;

-- Read policies (anon & authenticated can read)
create policy read_all_templates
  on public.templates for select
  using (true);

create policy read_all_broadcasts
  on public.template_broadcasts for select
  using (true);

-- Grants (service_role manages everything)
grant usage on schema public to postgres, anon, authenticated, service_role;
grant select on public.templates, public.template_broadcasts to anon, authenticated;
grant all on public.templates, public.template_broadcasts to service_role;
grant execute on function public.tg_touch_updated_at() to service_role;

------------------------------------------------------------
-- 3) Helper: request context debugger
------------------------------------------------------------
-- Returns the caller uid and role read from request.jwt.claims
create or replace function public.debug_ctx()
returns table(uid uuid, role text)
language sql
stable
security definer
set search_path = public, extensions
as $$
  select
    (case
       when coalesce(current_setting('request.jwt.claims', true), '') = '' then null::uuid
       else
         case
           when (coalesce(current_setting('request.jwt.claims', true),'{}')::jsonb ->> 'sub')
                ~ '^[0-9a-fA-F-]{36}$'
           then (coalesce(current_setting('request.jwt.claims', true),'{}')::jsonb ->> 'sub')::uuid
           else null::uuid
         end
     end) as uid,
    auth.role() as role;
$$;

grant execute on function public.debug_ctx() to anon, authenticated, service_role;

------------------------------------------------------------
-- 4) RPC: Upsert template (SERVICE-ROLE ONLY)
------------------------------------------------------------
create or replace function public.upsert_template_service_only(
  p_content_json jsonb default '{}'::jsonb,
  p_content_md   text default null,
  p_id           uuid default null,
  p_kind         text default 'generic',
  p_sex          text default 'u',
  p_set_id       uuid default null,
  p_status       text default 'draft',
  p_title        text default null,
  p_version      integer default 1
)
returns uuid
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_id uuid;
begin
  if auth.role() <> 'service_role' then
    raise exception 'service only' using errcode='P0001';
  end if;

  if p_id is null then
    insert into public.templates(kind, title, content_md, content_json, sex, status, version, set_id)
    values (coalesce(p_kind,'generic'), coalesce(p_title,'Untitled'),
            p_content_md, coalesce(p_content_json,'{}'::jsonb),
            coalesce(p_sex,'u'), coalesce(p_status,'draft'),
            coalesce(p_version,1), p_set_id)
    returning id into v_id;
  else
    update public.templates t
       set kind         = coalesce(p_kind, t.kind),
           title        = coalesce(p_title, t.title),
           content_md   = coalesce(p_content_md, t.content_md),
           content_json = coalesce(p_content_json, t.content_json),
           sex          = coalesce(p_sex, t.sex),
           status       = coalesce(p_status, t.status),
           version      = coalesce(p_version, t.version),
           set_id       = coalesce(p_set_id, t.set_id)
     where t.id = p_id
     returning id into v_id;

    if v_id is null then
      -- If not found, insert with the provided id
      insert into public.templates(id, kind, title, content_md, content_json, sex, status, version, set_id)
      values (p_id, coalesce(p_kind,'generic'), coalesce(p_title,'Untitled'),
              p_content_md, coalesce(p_content_json,'{}'::jsonb),
              coalesce(p_sex,'u'), coalesce(p_status,'draft'),
              coalesce(p_version,1), p_set_id)
      returning id into v_id;
    end if;
  end if;

  return v_id;
end;
$$;

grant execute on function public.upsert_template_service_only(jsonb, text, uuid, text, text, uuid, text, text, integer)
  to service_role;

------------------------------------------------------------
-- 5) RPC: Publish broadcast (SERVICE-ROLE ONLY)
------------------------------------------------------------
create or replace function public.publish_template_broadcast(
  p_template_id uuid,
  p_channel text default 'internal',
  p_payload jsonb default '{}'::jsonb
)
returns uuid
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_bid uuid;
begin
  if auth.role() <> 'service_role' then
    raise exception 'service only' using errcode='P0001';
  end if;

  insert into public.template_broadcasts(template_id, channel, status, payload)
  values (p_template_id, coalesce(p_channel,'internal'), 'queued', coalesce(p_payload,'{}'::jsonb))
  returning id into v_bid;

  return v_bid;
end;
$$;

grant execute on function public.publish_template_broadcast(uuid, text, jsonb)
  to service_role;

------------------------------------------------------------
-- 6) Sanity checks (you can run individually later)
-- select * from public.debug_ctx();
-- select id, kind, title, status, version from public.templates order by created_at desc limit 20;
-- select id, template_id, status, channel, created_at from public.template_broadcasts order by created_at desc limit 20;

-- Done.
