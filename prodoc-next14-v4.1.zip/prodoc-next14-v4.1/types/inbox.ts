// types/inbox.ts
export type ApplyMode = 'append' | 'replace' | 'merge';


export interface ApplyPayload {
submenuId: string; // destino obrigatório
mode: ApplyMode; // append | replace | merge
// Opcional: permitir apontar explicitamente uma fonte
source?: 'template' | 'cards';
templateId?: string; // se a fonte for um template específico
cardIds?: string[]; // se a fonte forem cards avulsos
}


export interface InboxItemPayload {
// payload livre vindo do broadcast/admin; suportamos alguns campos padrão
source?: 'template' | 'cards';
templateId?: string;
cardIds?: string[];
// pode conter metadados diversos (ex.: tags, título sugerido etc.)
[k: string]: unknown;
}