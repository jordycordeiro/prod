-- =====================================================================
-- PRODOC · SUPABASE SCHEMA (COMPLETO E IDEMPOTENTE)
-- =====================================================================
-- Extensões + convenções
create extension if not exists pgcrypto;
set search_path = public;

-- =====================================================================
-- TABELAS
-- =====================================================================

-- Perfis (apenas o que precisamos para admin; não cria a tabela inteira)
do $$
begin
  if not exists (
    select 1 from information_schema.columns
    where table_schema='public' and table_name='profiles' and column_name='is_admin'
  ) then
    alter table public.profiles add column is_admin boolean default false;
  end if;
  -- created_at para ordenação do fallback de admin (se não existir)
  if not exists (
    select 1 from information_schema.columns
    where table_schema='public' and table_name='profiles' and column_name='created_at'
  ) then
    alter table public.profiles add column created_at timestamptz default now();
  end if;
end $$;

-- Templates
create table if not exists public.templates (
  id            uuid primary key default gen_random_uuid(),
  title         text not null default '',
  kind          text not null default 'PADRAO',
  sex           text not null default 'A',               -- A/M/F
  content_md    text,
  content_json  jsonb not null default '{}'::jsonb,
  created_by    uuid,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- gatilho updated_at
create or replace function public._touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at := now(); return new; end $$;
drop trigger if exists trg_templates_touch on public.templates;
create trigger trg_templates_touch before update on public.templates
for each row execute procedure public._touch_updated_at();

comment on table public.templates is 'Modelos/prescrições administradas pelo painel.';

-- Broadcasts
create table if not exists public.broadcasts (
  id           uuid primary key default gen_random_uuid(),
  template_id  uuid not null references public.templates(id) on delete cascade,
  version      integer not null,
  created_by   uuid not null,
  created_at   timestamptz not null default now()
);

comment on table public.broadcasts is 'Publicações (fan-out) de templates.';

-- Inbox do usuário (notificações aplicáveis)
create table if not exists public.user_inbox (
  id             uuid primary key default gen_random_uuid(),
  user_id        uuid not null,
  broadcast_id   uuid not null references public.broadcasts(id) on delete cascade,
  template_id    uuid not null references public.templates(id) on delete cascade,
  version        integer not null,
  payload        jsonb not null default '{}'::jsonb,
  seen_at        timestamptz,
  applied_version integer,
  created_at     timestamptz not null default now()
);

-- Índice único (idempotente); ignora se já houver duplicatas
do $$
begin
  begin
    create unique index if not exists idx_user_inbox_user_bcast_unique
      on public.user_inbox(user_id, broadcast_id);
  exception when others then null; end;
end $$;

-- =====================================================================
-- RLS
-- =====================================================================

alter table public.templates enable row level security;
alter table public.broadcasts enable row level security;
alter table public.user_inbox enable row level security;

-- limpa policies antigas para evitar conflito
do $$
begin
  for r in select policyname from pg_policies where schemaname='public' and tablename in ('templates','broadcasts','user_inbox')
  loop execute format('drop policy if exists %I on public.%I', r.policyname,
                      (select tablename from pg_policies where policyname=r.policyname limit 1));
  end loop;
exception when others then null;
end $$;

-- templates: leitura para autenticados
create policy "templates select" on public.templates
for select to authenticated using (true);

-- templates: escrita via função security definer (admin) ou service_role
create policy "templates write service" on public.templates
for all to public
using (auth.role() = 'service_role')
with check (auth.role() = 'service_role');

-- broadcasts: leitura para autenticados
create policy "broadcasts select" on public.broadcasts
for select to authenticated using (true);

-- user_inbox: cada usuário só enxerga a sua caixa
create policy "inbox select own" on public.user_inbox
for select to authenticated using (user_id = auth.uid());

-- user_inbox: permitir o próprio usuário marcar como visto (se você quiser liberar via client)
create policy "inbox update own" on public.user_inbox
for update to authenticated
using (user_id = auth.uid()) with check (user_id = auth.uid());

-- =====================================================================
-- HELPERS
-- =====================================================================

-- Debug do contexto (útil em testes)
create or replace function public.debug_ctx()
returns table(uid uuid, role text)
language plpgsql stable security definer
as $$
begin
  return query select
    nullif(current_setting('request.jwt.claims', true)::jsonb->>'sub','')::uuid,
    auth.role();
end; $$;

-- =====================================================================
-- RPCs (ADMIN/APP)
-- =====================================================================

-- Upsert admin: exige admin em profiles; gera UUID quando não vier id
create or replace function public.admin_upsert_template(
  _id uuid,
  _title text,
  _kind text,
  _sex text,
  _content_md text,
  _content_json jsonb
) returns public.templates
language plpgsql
security definer
set search_path = public
as $$
declare
  row public.templates;
  is_admin boolean;
  new_id uuid := coalesce(_id, gen_random_uuid());
begin
  select coalesce(p.is_admin, false) into is_admin
  from public.profiles p where p.id = auth.uid();

  if not is_admin then
    raise exception 'not_authorized';
  end if;

  insert into public.templates as t (id, title, kind, sex, content_md, content_json, created_by)
  values (new_id, coalesce(_title,''), coalesce(_kind,'PADRAO'), coalesce(_sex,'A'),
          _content_md, coalesce(_content_json,'{}'::jsonb), auth.uid())
  on conflict (id) do update set
    title        = excluded.title,
    kind         = excluded.kind,
    sex          = excluded.sex,
    content_md   = excluded.content_md,
    content_json = excluded.content_json,
    updated_at   = now()
  returning * into row;

  return row;
end;
$$;

-- Publicar template → cria broadcast e fan-out na inbox
-- Preenche template_id, version e payload; created_by com fallback robusto
create or replace function public.admin_publish_template(
  template_id uuid,
  version integer,
  created_by uuid default null
) returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  bcast_id uuid;
  uid uuid;
  payload_val jsonb;
begin
  -- resolve created_by: explícito -> auth.uid() -> primeiro admin
  select coalesce(
    created_by,
    auth.uid(),
    (select p.id from public.profiles p where coalesce(p.is_admin, false) = true
     order by p.created_at nulls last limit 1)
  ) into uid;

  if uid is null then
    raise exception 'missing_created_by_fallback';
  end if;

  -- payload padrão (inclui título, mas é opcional)
  select jsonb_build_object(
    'kind','template_update',
    'template_id', template_id,
    'version', version,
    'title', (select t.title from public.templates t where t.id = template_id limit 1)
  ) into payload_val;

  -- cria broadcast
  insert into public.broadcasts (template_id, version, created_by)
  values (template_id, version, uid)
  returning id into bcast_id;

  -- fan-out: evita duplicar sem precisar de ON CONFLICT
  insert into public.user_inbox (user_id, broadcast_id, template_id, version, payload)
  select p.id, bcast_id, template_id, version, payload_val
  from public.profiles p
  where not exists (
    select 1 from public.user_inbox ui
    where ui.user_id = p.id and ui.broadcast_id = bcast_id
  );

  return bcast_id;
end;
$$;

-- Aplicar notificação pelo usuário (marca visto/aplicado)
create or replace function public.apply_template_for_user(bcast_id uuid)
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  r record;
begin
  select ui.*
  into r
  from public.user_inbox ui
  where ui.broadcast_id = bcast_id
    and ui.user_id = auth.uid()
  limit 1;

  if not found then
    return 'broadcast_not_found';
  end if;

  if r.seen_at is not null and r.applied_version is not null then
    return 'already_applied';
  end if;

  update public.user_inbox
     set seen_at = now(),
         applied_version = coalesce(r.version, r.applied_version)
   where id = r.id;

  return 'applied';
end;
$$;

-- =====================================================================
-- PGRST: recarregar schema
-- =====================================================================
select pg_notify('pgrst','reload schema');
