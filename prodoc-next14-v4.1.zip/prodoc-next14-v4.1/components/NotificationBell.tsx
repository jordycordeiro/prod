// components/NotificationBell.tsx
'use client'

import { useEffect, useState } from 'react'
import { Bell } from 'lucide-react'
import { getInbox } from '@/app/(prodoc)/actions/notifications'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { createClient } from '@/lib/supabase/client'

export default function NotificationBell() {
  const [inbox, setInbox] = useState<any[]>([])
  const [open, setOpen] = useState(false)
  const [onlyUnread, setOnlyUnread] = useState(true)
  const [busyId, setBusyId] = useState<string | null>(null)

  async function load() {
    const data = await getInbox(onlyUnread)
    setInbox(data || [])
  }

  useEffect(() => {
    let timer: any
    ;(async () => {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()
      await load()

      const filter = user?.id ? `user_id=eq.${user.id}` : undefined
      const channel = supabase.channel('realtime:user_inbox')
        .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'user_inbox', filter }, () => load())
        .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'user_inbox', filter }, () => load())
        .subscribe()

      timer = setInterval(load, 20000)
      return () => { supabase.removeChannel(channel); if (timer) clearInterval(timer) }
    })()
  }, [onlyUnread])

  const unreadCount = inbox.filter(i => !i.seen_at && (!i.muted_until_version || i.version > i.muted_until_version)).length

  async function handleIgnore(itemId: string) {
    const prev = inbox
    setBusyId(itemId)
    if (onlyUnread) setInbox(prev.filter(i => i.id !== itemId))

    let ok = false
    try {
      const res = await fetch(`/api/inbox/ignore/${itemId}`, { method: 'PATCH' })
      ok = res.ok
    } catch {}

    if (!ok) {
      try {
        const supabase = createClient()
        const { error } = await supabase
          .from('user_inbox')
          .update({ seen_at: new Date().toISOString() })
          .eq('id', itemId)
        ok = !error
      } catch {}
    }

    if (!ok) {
      setInbox(prev)
      console.error('Ignorar falhou (rota e fallback). Verifique coluna seen_at, RLS e user_id.')
      alert('Não foi possível ignorar. Veja o console para detalhes.')
    }

    setBusyId(null)
  }

  return (
    <div className="relative">
      <button onClick={() => setOpen(!open)} className="relative rounded-full p-2 hover:bg-gray-100">
        <Bell className="w-6 h-6 text-blue-600" />
        {unreadCount > 0 && (
          <span className="absolute -top-0.5 -right-0.5 bg-red-500 text-white text-[10px] px-1.5 rounded-full">
            {unreadCount}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute right-0 mt-2 w-96 bg-white rounded-2xl shadow-xl p-2 border border-gray-200 z-50">
          <div className="flex items-center gap-2 px-2 pb-2">
            <button
              className={`text-xs px-2 py-1 rounded-full border ${onlyUnread ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-gray-600 border-gray-300'}`}
              onClick={() => setOnlyUnread(true)}
            >
              Não lidas
            </button>
            <button
              className={`text-xs px-2 py-1 rounded-full border ${!onlyUnread ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-gray-600 border-gray-300'}`}
              onClick={() => setOnlyUnread(false)}
            >
              Todas
            </button>
          </div>

          {inbox.length === 0 && (
            <div className="text-center text-gray-400 py-6">Sem notificações {onlyUnread ? 'não lidas' : ''}</div>
          )}

          {inbox.map((item) => {
            const title = item?.templates?.title ?? 'Atualização disponível'
            const version = item?.version
            const read = Boolean(item?.seen_at)
            return (
              <Card key={item.id} className={`mb-2 ${read ? 'bg-gray-50' : 'bg-white'} rounded-2xl border`}>
                <CardContent className="p-3">
                  <div className="font-semibold text-blue-700">{title}</div>
                  {version && <div className="text-xs text-gray-500 mb-2">Versão {version}</div>}
                  {!read ? (
                    <div className="flex gap-2">
                      <Button size="sm" variant="ghost" disabled={busyId === item.id} onClick={() => handleIgnore(item.id)}>
                        {busyId === item.id ? 'Ignorando...' : 'Ignorar'}
                      </Button>
                    </div>
                  ) : (
                    <span className="text-green-600 text-sm">Lido</span>
                  )}
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}
    </div>
  )
}
