'use client'

import { useEffect, useState } from 'react'
import UpdatesDrawer from '@/components/inbox/UpdatesDrawer'

export default function TopbarBell() {
  const [open, setOpen] = useState(false)
  const [count, setCount] = useState(0)

  // nova versão: busca via /api/inbox/count
  async function refreshCount() {
    try {
      const res = await fetch('/api/inbox/count', { cache: 'no-store' })
      const data = await res.json()
      const c = data?.count ?? 0
      setCount(c)
    } catch {
      // fallback simples se endpoint falhar
      setCount(0)
    }
  }

  useEffect(() => { refreshCount() }, [])

  return (
    <>
      <button className="relative btn-chip" onClick={() => setOpen(true)}>
        🔔
        {count > 0 && (
          <span className="absolute -top-1 -right-1 text-[10px] bg-red-500 text-white rounded-full px-1">
            {count}
          </span>
        )}
      </button>
      <UpdatesDrawer
        open={open}
        onClose={() => {
          setOpen(false)
          refreshCount()
        }}
      />
    </>
  )
}
