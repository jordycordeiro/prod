'use client'

import { useEffect, useState } from 'react'

type InboxItem = {
  id: string
  status: 'unread' | 'read' | 'applied' | 'ignored'
  payload: any
  created_at: string
}

export default function UpdatesDrawer({
  open,
  onClose,
}: {
  open: boolean
  onClose: () => void
}) {
  const [items, setItems] = useState<InboxItem[]>([])
  const [loading, setLoading] = useState(false)

  async function refresh() {
    setLoading(true)
    try {
      const res = await fetch('/api/inbox/list', { cache: 'no-store' })
      const rows: InboxItem[] = await res.json()
      setItems(rows ?? [])

      const unread = (rows ?? []).filter(r => r.status === 'unread').map(r => r.id)
      if (unread.length) {
        await fetch('/api/inbox/mark-read', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ ids: unread }),
        })
      }
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (open) refresh()
  }, [open])

  return (
    <div
      className={`fixed inset-y-0 right-0 w-[380px] bg-white shadow-xl border-l transition-transform ${
        open ? 'translate-x-0' : 'translate-x-full'
      }`}
    >
      <div className="p-4 flex items-center justify-between border-b">
        <h3 className="font-semibold">Atualizações</h3>
        <button className="btn-chip" onClick={onClose}>Fechar</button>
      </div>

      <div className="p-4">
        {loading && <div className="text-sm text-neutral-500">Carregando…</div>}
        {!loading && items.length === 0 && (
          <div className="text-sm text-neutral-500">Nenhuma atualização.</div>
        )}

        <ul className="space-y-3">
          {items.map((it) => {
            const p = it.payload || {}
            const title = p?.cards?.[0]?.title ?? p?.title ?? 'Atualização'
            const preview = p?.cards?.[0]?.content_md ?? p?.note ?? ''
            return (
              <li key={it.id} className="rounded-lg border p-3">
                <div className="text-sm font-medium">{title}</div>
                {preview && (
                  <div className="mt-1 text-xs text-neutral-600 line-clamp-3 whitespace-pre-wrap">
                    {preview}
                  </div>
                )}
                <div className="mt-2 text-[11px] text-neutral-400">
                  {new Date(it.created_at).toLocaleString()}
                  {it.status === 'unread' && <span className="ml-2 text-blue-600">• novo</span>}
                </div>
              </li>
            )
          })}
        </ul>
      </div>
    </div>
  )
}
