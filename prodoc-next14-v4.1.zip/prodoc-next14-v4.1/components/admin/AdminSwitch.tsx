"use client";

import React from "react";
import { useProdocStore } from "@/components/useProdocStore";

// Componentes já usados pelo usuário (mantêm o visual padrão)
import ExameFisico from "@/components/ExameFisico";
import Observacoes from "@/components/Observacoes";
import Medicacoes from "@/components/Medicacoes";
// Composer padrão para Patologias (o mesmo do usuário)
import Canvas from "@/components/Canvas";

/** Helpers mínimos para localizar o item raiz ativo (mesmo raciocínio do Canvas) */
type NodeLike = { [k: string]: any };
const getKeyOf = (it: NodeLike) => it?.key || it?.path || it?.id;

function findNodeInArray(arr: any[], key: string): NodeLike | null {
  for (const it of arr) {
    if (!it || typeof it !== "object") continue;
    if (getKeyOf(it) === key) return it;
    if (Array.isArray(it.children)) {
      const f = findNodeInArray(it.children, key);
      if (f) return f;
    }
  }
  return null;
}
function findParentOfKey(arr: any[], key: string): NodeLike | null {
  for (const it of arr) {
    if (!it || typeof it !== "object") continue;
    if (Array.isArray(it.children) && it.children.some((c: any) => getKeyOf(c) === key)) return it;
    if (Array.isArray(it.children)) {
      const f = findParentOfKey(it.children, key);
      if (f) return f;
    }
  }
  return null;
}
function getRootScopeLabel(state: any, activeKey: string): string | null {
  const items: any[] = (state?.sidebar?.items ?? []) as any[];
  if (!Array.isArray(items) || !activeKey) return null;

  // sobe até o topo
  let curKey = activeKey;
  let parent = findParentOfKey(items, curKey);
  let lastParent: NodeLike | null = null;
  while (parent) {
    lastParent = parent;
    curKey = getKeyOf(parent);
    parent = findParentOfKey(items, curKey);
  }
  const root = lastParent || findNodeInArray(items, activeKey);
  const label = (root?.label || root?.name || root?.title || "").toString().trim();
  return label || null;
}
function mapLabelToScope(label: string): "exame_fisico" | "observacoes" | "medicacoes" | "patologia" | null {
  const l = (label || "").toLowerCase();
  if (l.startsWith("exame físico") || l.startsWith("exame fisico")) return "exame_fisico";
  if (l.startsWith("queixas")) return "observacoes";
  if (l.startsWith("medicações") || l.startsWith("medicacoes")) return "medicacoes";
  if (l.startsWith("patologias")) return "patologia";
  return null;
}

export default function AdminSwitch() {
  const { state } = useProdocStore();
  const activeKey = state?.activeKey as string;

  const rootLabel = React.useMemo(() => getRootScopeLabel(state, activeKey), [state, activeKey]);
  const scope = React.useMemo(() => (rootLabel ? mapLabelToScope(rootLabel) : null), [rootLabel]);

  // Nada selecionado ainda (mensagem padrão já existente)
  if (!activeKey) {
    return <div className="p-6 text-sm opacity-70">Selecione um item na barra lateral para começar.</div>;
  }

  // Para os três menus pai, reaproveitamos os componentes do usuário (mesmo look & feel)
  if (scope === "exame_fisico") return <ExameFisico />;
  if (scope === "observacoes") return <Observacoes />;
  if (scope === "medicacoes") return <Medicacoes />;

  // Para Patologias, mantemos o composer padrão (Canvas) — igual ao usuário
  return <Canvas />;
}
