'use client'

import { useState } from 'react'

export function usePublish() {
  const [loading, setLoading] = useState(false)
  const [toast, setToast] = useState<{type:'success'|'error'|'info', msg:string} | null>(null)

  const show = (msg: string, type: 'success'|'error'|'info'='info') => {
    setToast({ type, msg })
    setTimeout(() => setToast(null), 2500)
  }

  async function publish(card: { id?: string; submenu_id: string; title: string; content_md: string }) {
    setLoading(true)
    try {
      const r = await fetch('/api/admin/publish', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(card),
      })
      const j = await r.json()
      if (!j?.ok) throw new Error(j?.error || 'Falha ao publicar')
      show(`Publicado v${j.version}`, 'success')
      return j
    } catch (e: any) {
      show(e?.message || 'Erro ao publicar', 'error')
      throw e
    } finally {
      setLoading(false)
    }
  }

  function Toast() {
    if (!toast) return null
    return (
      <div
        className={[
          'fixed right-6 bottom-6 z-50 rounded-lg px-4 py-2 text-sm shadow-lg',
          toast.type==='success' ? 'bg-green-600 text-white' :
          toast.type==='error'   ? 'bg-red-600 text-white' :
                                   'bg-neutral-800 text-white'
        ].join(' ')}
      >
        {toast.msg}
      </div>
    )
  }

  return { publish, loading, Toast }
}
