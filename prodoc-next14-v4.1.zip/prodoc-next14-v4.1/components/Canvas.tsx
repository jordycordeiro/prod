"use client";

import React, { useEffect, useState } from "react";
import { useProdocStore } from "./useProdocStore";
import { listEffectiveCards } from "@/app/(app)/prodoc/data";

/** === Admin Studio: blocos de Exame/Queixas/Medicações === */
import { AdminBlockList } from "@/components/admin/BlockList";
import { AdminTextEditor } from "@/components/admin/TemplateEditor";

type Card = { id: string; title: string; content: string };
type NodeLike = { [k: string]: any };

const STABLE_KEY = "prodoc-stable-v1";
const STORE_KEY = "prodoc-store-v1";

const SECTION_TITLES = ["USO ORAL", "USO EV", "USO IM", "USO SC", "USO INALATÓRIO", "USO TÓPICO"];
const isSection = (t: string) => SECTION_TITLES.includes((t || "").trim().toUpperCase());
const isNotes = (t: string) => (t || "").trim().toUpperCase() === "NOTAS";
const isMedicationItem = (t: string) => /^\s*\d+\.\s+/m.test(t || "");

const notify = (m: string) => {
  try {
    (window as any)?.toast?.(m);
  } catch {}
  try {
    alert(m);
  } catch {}
};

const persist = (s: any) => {
  try {
    localStorage.setItem(STORE_KEY, JSON.stringify(s));
  } catch {}
};

/* ---------------- helpers p/ sidebar/menu ---------------- */
const getKeyOf = (it: NodeLike) => it?.key || it?.path || it?.id;
function findNodeInArray(arr: any[], key: string): NodeLike | null {
  for (const it of arr) {
    if (!it || typeof it !== "object") continue;
    if (getKeyOf(it) === key) return it;
    if (Array.isArray(it.children)) {
      const f = findNodeInArray(it.children, key);
      if (f) return f;
    }
  }
  return null;
}

function mapLabelToScope(label: string): "exame_fisico" | "observacoes" | "medicacoes" | null {
  const l = (label || "").toLowerCase();
  if (l.startsWith("exame físico") || l.startsWith("exame fisico")) return "exame_fisico";
  if (l.startsWith("queixas")) return "observacoes";
  if (l.startsWith("medicações") || l.startsWith("medicacoes")) return "medicacoes";
  return null;
}

/* -------------------------------------------------------------------------- */

export default function Canvas() {
  const { state, actions }: any = useProdocStore();
  const activeKey = state?.activeKey as string;
  const current = React.useMemo(() => state?.paths?.[activeKey] || state?.pages?.[activeKey] || null, [state, activeKey]);
  const cards = React.useMemo<Card[]>(() => (current?.cards ?? []) as Card[], [current]);
  const [, force] = React.useReducer((x) => x + 1, 0);

  /** === Detecta se é seção admin === */
  const rootLabel = React.useMemo(() => {
    const list: any[] = (state?.sidebar?.items ?? []) as any[];
    const node = findNodeInArray(list, activeKey);
    return (node?.label || node?.name || node?.title || "").trim();
  }, [state, activeKey]);
  const adminScope = React.useMemo(() => mapLabelToScope(rootLabel), [rootLabel]);

  /** === NOVO BLOCO: se não for admin, buscar cards globais do banco === */
  const [globalCards, setGlobalCards] = useState<Card[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    async function fetchCards() {
      setLoading(true);
      try {
        if (!adminScope && activeKey) {
          const submenuId = state?.submenuId || state?.activeKey || "";
          const rows = await listEffectiveCards(submenuId);
          setGlobalCards(rows.map(r => ({
            id: r.user_card_id || r.admin_card_id,
            title: r.title,
            content: r.content_md
          })));
        }
      } finally {
        setLoading(false);
      }
    }
    fetchCards();
  }, [activeKey]);

  /** === Se for adminScope, renderiza modo Admin === */
  if (adminScope) {
    return (
      <div className="p-0">
        <div
          className="prodoc-surface relative"
          style={{
            background: "#fff",
            borderRadius: 20,
            overflow: "hidden",
            border: "1px solid rgba(10,112,199,.15)",
            boxShadow: "0 18px 44px rgba(2,80,200,.10)",
          }}
        >
          <div
            className="prodoc-surface__header"
            style={{
              background: "linear-gradient(180deg, var(--brand,#0a70c7), var(--brand-2,#1e40af))",
              color: "#fff",
              padding: "10px 16px",
              fontWeight: 700,
            }}
          >
            {rootLabel || "Blocos"}
          </div>
          <div className="grid gap-6 p-4 lg:grid-cols-[280px_minmax(0,1fr)]">
            <div>
              <AdminBlockList scope={adminScope} onPick={(id) => {}} />
            </div>
            <div>
              <AdminTextEditor templateId={null as any} />
            </div>
          </div>
        </div>
      </div>
    );
  }

  /** === Caso não seja admin, renderiza prescrições globais === */
  if (loading)
    return <div className="p-6 text-sm opacity-70">Carregando prescrições...</div>;

  if (globalCards.length === 0)
    return <div className="p-6 text-sm opacity-70">Nenhuma prescrição publicada ainda.</div>;

  return (
    <div className="p-0">
      <div
        className="prodoc-surface relative"
        style={{
          background: "#fff",
          borderRadius: 20,
          overflow: "hidden",
          border: "1px solid rgba(10,112,199,.15)",
          boxShadow: "0 18px 44px rgba(2,80,200,.10)",
        }}
      >
        <div
          className="prodoc-surface__header"
          style={{
            background: "linear-gradient(180deg, var(--brand,#0a70c7), var(--brand-2,#1e40af))",
            color: "#fff",
            padding: "10px 16px",
            fontWeight: 700,
          }}
        >
          Prescrições publicadas
        </div>

        <div className="p-4 space-y-3">
          {globalCards.map((card: Card) => (
            <div
              key={card.id}
              className="rounded-xl border border-blue-100 bg-blue-50/50"
            >
              <div className="px-4 py-2 text-blue-900 font-semibold">{card.title}</div>
              <pre className="px-4 pb-3 whitespace-pre-wrap text-[15px]">{card.content}</pre>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
