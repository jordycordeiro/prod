// hooks/useUserInbox.ts
'use client'

import { useEffect, useMemo, useState } from 'react'
import { createClient } from '@supabase/supabase-js'
import toast from '@/lib/toast'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
)

export type InboxRow = {
  id: string
  user_id: string
  title: string | null
  body: string | null
  link: string | null
  status: 'unread' | 'read' | 'archived' | null
  created_at: string
}

export function useUserInbox(userId?: string | null) {
  const [items, setItems] = useState<InboxRow[]>([])
  const unreadCount = useMemo(
    () => items.filter(i => i.status === 'unread').length,
    [items]
  )

  // 1) carga inicial
  useEffect(() => {
    if (!userId) return
    ;(async () => {
      const { data, error } = await supabase
        .from('user_inbox')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(50)

      if (!error && data) setItems(data as InboxRow[])
    })()
  }, [userId])

  // 2) realtime + toast em novas notificações
  useEffect(() => {
    if (!userId) return

    const channel = supabase
      .channel(`inbox:${userId}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'user_inbox', filter: `user_id=eq.${userId}` },
        (payload) => {
          const row = payload.new as InboxRow
          setItems(prev => [row, ...prev])
          toast(row.title ?? 'Nova notificação', { type: 'info', durationMs: 4500 })
        }
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'user_inbox', filter: `user_id=eq.${userId}` },
        (payload) => {
          const row = payload.new as InboxRow
          setItems(prev => prev.map(i => (i.id === row.id ? row : i)))
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [userId])

  // 3.3 listar & marcar como lidas
  async function markAsRead(id: string) {
    const { error } = await supabase.from('user_inbox').update({ status: 'read' }).eq('id', id)
    if (!error) setItems(prev => prev.map(i => (i.id === id ? { ...i, status: 'read' } : i)))
  }

  async function markAllAsRead() {
    const ids = items.filter(i => i.status === 'unread').map(i => i.id)
    if (!ids.length) return
    const { error } = await supabase.from('user_inbox').update({ status: 'read' }).in('id', ids)
    if (!error) setItems(prev => prev.map(i => (i.status === 'unread' ? { ...i, status: 'read' } : i)))
  }

  return { items, unreadCount, markAsRead, markAllAsRead }
}
